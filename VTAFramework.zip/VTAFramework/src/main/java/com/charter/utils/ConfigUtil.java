package com.charter.utils;

import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;

import org.json.JSONObject;


/**
 * {@code ConfigUtil} Handles config.json and provides an access interface.
 */
public class ConfigUtil {
	public static String CONFIG_ENV = "development";  
	public static String FILE_PATH  = "config.json";
	
	private static JSONObject CONFIG_JSON;
	
	private static JSONObject CONFIG_VALS() {
		reloadConfig();
		return CONFIG_JSON.getJSONObject(CONFIG_ENV);
	}
	
	public static JSONObject CONFIG_SERV(String serverKey) {
		return CONFIG_VALS().getJSONObject(serverKey);
	}
	
	public static String CONFIG_GET_STRING(String key) {
		String[] str = key.split("[.]");
		if (str.length < 2) { return ""; }
		return CONFIG_SERV(str[0]).getString(str[1]);
	}
	
	public static String CONFIG_SERVER_GET_STRING(String serverKey, String key) {
		return CONFIG_SERV(serverKey).getString(key);
	}
	
	public static JSONObject CONFIG_SERVER_GET_JOBJ(String serverKey, String key) {
		return CONFIG_SERV(serverKey).getJSONObject(key);
	}
	
	public static String BASEURI(String serverKey) {
		return CONFIG_SERVER_GET_STRING(serverKey, "baseURI");
	}
	
	public static JSONObject ENDPOINTS(String serverKey) {
		return CONFIG_SERVER_GET_JOBJ(serverKey, "endpoints");
	}
	
	public static String ENDPOINT(String serverKey, String key) {
		return ENDPOINTS(serverKey).getString(key);
	}
	
	
	
//	public static String ENDPOINT(String serverKey, String endpointKey) {
//		return CONFIG_VALS().getJSONObject(serverKey).getJSONObject("endpoints");
//	}
	
//	public static void main(String args[]) {
//		
//		//JSONObject jo = new JSONObject("{\"city\":\"chicago\",\"name\":\"jon doe\",\"age\":\"22\"}");
//		
//		CONFIG_JSON = reloadConfig();
//		
//		System.out.println("CONFIG   : " + CONFIG_SERV("auth") );
//		System.out.println("URI      : " + BASEURI("auth") );
//		System.out.println("Endpoints: " + ENDPOINTS("auth") );
//		System.out.println("Endpoint : " + ENDPOINT("auth", "Val2") );
//	}
	
	public static JSONObject reloadConfig() {
		
		ConfigUtil util = new ConfigUtil();
		
		String configString = "";
		
		try {
			configString = util.readFile(FILE_PATH);
			
		} catch(URISyntaxException error) {
			System.out.println("Config File Error: " + error.getMessage());
			
			return null;
		}
		
		CONFIG_JSON = new JSONObject(configString);
		
		ConfigUtil.CONFIG_ENV = CONFIG_JSON.getString("activeEnv");
		
		return CONFIG_JSON;
	}
	
	/**
	 * Load contents of the file data.
	 * 
	 * @filePath dirPath absolute path to directory
	 * @return String - Data read from the file, returned String is empty if read failed.
	 * @throws URISyntaxException 
	 */
	private String readFile(String filePath) throws URISyntaxException {
		
		try {
			// get the file url, not working in JAR file.
			URL resource = getClass().getClassLoader().getResource("config.json");
			if (resource == null) {
				throw new IllegalArgumentException("file not found!");
			} else {
				// failed if files have whitespaces or special characters
				//return new File(resource.getFile());
				
				File myObj = new File(resource.toURI());
				//File myObj = new File(filePath);
					Scanner myReader = new Scanner(myObj);
					
					String data = "";
					
					while (myReader.hasNextLine()) {
						data = data + myReader.nextLine();
						
					}
					
					myReader.close();
					
					return data;
			}
			  
			
			
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
			
		}
		
		return "";
	}
}
