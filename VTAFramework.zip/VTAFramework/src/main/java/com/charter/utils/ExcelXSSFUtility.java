package com.charter.utils;

import java.io.File;  
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;  
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;

public class ExcelXSSFUtility {
//	public static void main(String[] args) {
//		List<String> values = ExcelXSSFUtility.valuesFor("channel");
//		
//		for(int i = 0; i < values.size(); i++) {
//			System.out.println("Val: " + values.get(i));
//		}
//	}
	private static String FILE_PATH = "vtf_datasheet.xlsx";
	
	public static List<String> valuesFor(String key) {
		List<String> values = new ArrayList<String>();
		
		try {
			
			//URL resource = getClass().getClassLoader().getResource("/vtf_datasheet.xlsx");
			
			File file;
			try {
				file = getFileFromURL();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("File not found: " + e.getMessage());
				return null;
			}//new File(resource.toURI());   //creating a new file instance 
			
			
			FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file  
			//creating Workbook instance that refers to .xlsx file  
			XSSFWorkbook wb = new XSSFWorkbook(fis);   
			XSSFSheet sheet = wb.getSheetAt(0);     //creating a Sheet object to retrieve object  
			Iterator<Row> itr = sheet.iterator();    //iterating over excel file
			
			Integer rowIndex = 0;
			Integer foundIndex = -1;
			while (itr.hasNext()) {
				Row row = itr.next();
				Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column
				
				//System.out.println("R: " + row.);
				
				Integer cellIndex = 0;
				
				//
				//
				
				if (foundIndex < 0) {
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						
//						switch (cell.getCellType()) {
//						case STRING:    //field that represents string cell type  
//							//System.out.print(cell.getStringCellValue() + "\t\t\t");
//							break;
//						case NUMERIC:    //field that represents number cell type  
//							//System.out.print(cell.getNumericCellValue() + "\t\t\t");
//							break;
//						default:
//						}
						
						//System.out.println("cellVal: " + cell.getStringCellValue() + ", key: " + key + ", RES: " + (cell.getStringCellValue().equals(key) ) );
						
						if ( cell.getStringCellValue().equals(key) ) {
							foundIndex = cellIndex;
							break;
						}
						
						cellIndex++;
					}
				} else {
					Cell cellVal = CellUtil.getCell(row, foundIndex);
					values.add(cellVal.getStringCellValue());
					//System.out.println("CEL: " + cell2);
				}
				
				
				//System.out.println("");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		values.removeIf(Objects::isNull);
		values.removeIf(String::isEmpty);
				
		return values;
	}
	
	private static File getFileFromURL() throws URISyntaxException {
	    URL url = new ExcelXSSFUtility().getClass().getClassLoader().getResource(FILE_PATH);
	    File file = null;
	    file = new File(url.toURI());
//	    try {
//	        file = new File(url.toURI());
//	    } catch (URISyntaxException e) {
//	        file = new File(url.getPath());
//	    } finally {
//	        return file;
//	    }
	    return file;
	}
}