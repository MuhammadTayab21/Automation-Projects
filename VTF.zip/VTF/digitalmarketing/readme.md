Process to get the project up and running on your local machine<br />
<ol>
    <li> Make sure you have JDK installed on your system </li>
    <li> Clone the repo to your local system </li>
    <li> Install Eclipse </li>
    <li> In Eclipse Goto File > Import > Imort Existing Maven Project 
        <ol>
            <li>Browse to local repo folder and click finish</li>
        </ol>
    </li>
    <li> Install Plugins 
        <ol>
            <li><b>TestNG:</b> https://marketplace.eclipse.org/content/testng-eclipse</li>
            <li><b>Cucumber:</b> https://www.toolsqa.com/cucumber/install-cucumber-eclipse-plugin/</li>
        </ol>
    </li>
    <li> Goto src/test/java/runners/ 
        <ol>
            <li>Right click on <b>RunAPITests.java</b> and select <i>RunAs > TestNGTest<i></li>
        </ol>
    </li>
</ol>