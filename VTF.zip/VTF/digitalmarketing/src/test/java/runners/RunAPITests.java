package runners;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		//features = { "src/main/java/features/api" },
		features = { "src/test/java/features/api" },
		glue = { "project.api" }, 
		//tags = { "not @ignore" },
		//tags = { "@AuthRequests" },
		tags = { "@Iterator" },
		plugin = { "pretty", "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"io.qameta.allure.cucumber4jvm.AllureCucumber4Jvm", "html:target/cucumber-html-default",
				"json:target/cucumber-report.json",
				"junit:target/cucumber-report.xml" },
		snippets = SnippetType.UNDERSCORE, 
		monochrome = true,
		strict = true,
		dryRun = false)
public class RunAPITests extends AbstractTestNGCucumberTests {}

