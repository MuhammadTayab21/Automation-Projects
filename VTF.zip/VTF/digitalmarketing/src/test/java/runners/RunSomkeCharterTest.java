package runners;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import org.testng.annotations.Listeners;

@CucumberOptions(
		//features = { "src/main/resources/features" },
		features = { "src/test/java/features/home" },
		glue = { "project.stepdefs" },
		tags = { "@Smoke" },
		plugin = { "pretty",
				"io.qameta.allure.cucumber4jvm.AllureCucumber4Jvm",
				"html:target/cucumber-html-default",
				"json:target/cucumber-report.json",
				"junit:target/cucumber-report.xml" }, 
		snippets = SnippetType.UNDERSCORE, 
		monochrome = true, 
		strict = true, 
		dryRun = false)

@Listeners({ExtentITestListenerClassAdapter.class}) 
public class RunSomkeCharterTest extends AbstractTestNGCucumberTests {
}
