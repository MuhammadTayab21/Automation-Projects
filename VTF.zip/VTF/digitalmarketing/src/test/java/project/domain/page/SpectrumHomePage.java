package project.domain.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import com.charter.web.Selenium;

public class SpectrumHomePage {
	private Selenium webDr = null;
	
	public SpectrumHomePage(Selenium webDr) {
		this.webDr=webDr;
	    }
	
	
	@FindBy(css = "a[title='About Charter']")
    @CacheLookup
    private WebElement aboutCharter;

    @FindBy(css = "a[title='Accessibility']")
    @CacheLookup
    private WebElement accessibility;

    @FindBy(css = "a[title='Affordable Connectivity Program']")
    @CacheLookup
    private WebElement affordableConnectivityProgram;

    @FindBy(id = "apt-tablet")
    @CacheLookup
    private WebElement aptunitOptional1;

    @FindBy(id = "apt-mobile")
    @CacheLookup
    private WebElement aptunitOptional2;
    
    @FindBy(xpath = "//header/div[2]/div[1]/div[1]/div[2]/div[1]/nav[1]/ul[1]/li[2]/a[1]")
    @CacheLookup
    private WebElement business;
    
    @FindBy(xpath = "//header/div[2]/div[1]/div[1]/div[2]/div[2]/nav[1]/ul[1]/li[2]/a[1]")
    @CacheLookup
	public WebElement internetTab; 
    
    @FindBy(xpath = "//button[text()='Offers']") //data-linkname="Offers"
  //Link[text()='Suchen'
 //   title="Offers"
    		
    @CacheLookup
	public WebElement offerTab;
    
    public SpectrumHomePage clickAboutCharterLink() {
        webDr.getNgWebDriver().waitForAngularRequestsToFinish();
        return this;
    }
   
    public SpectrumHomePage internetTabClick() {
    	webDr.elementToBeClickable(internetTab).click();;
        return this;
    }
    
    public SpectrumHomePage offerTabClick() {
    	webDr.waitForAngular();
    	webDr.elementToBeClickable(offerTab).click();
        return this;
    }
    
    public SpectrumHomePage businessLinkClick() {
    	//webDr.textToBePresentInElementValue(offerTab,"Offers").compareTo(true);
        return this;
    }

}
