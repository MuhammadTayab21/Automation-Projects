package project.stepdefs;

import org.assertj.core.api.Assertions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import project.domain.page.SpectrumHomePage;
import com.charter.web.Selenium;

/**
 * Define reusable steps for any application.
 */
public class CommonSteps {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonSteps.class);
	private Selenium selenium = null;
	private SpectrumHomePage specHome;

	public CommonSteps(ContextSteps contextSteps) {
		selenium = contextSteps.getSelenium();
		specHome = new SpectrumHomePage(selenium);
	}

	@Given("I Am At Page: {string}")
	public void I_Am_At_Page(String key) throws Throwable {
		String url = selenium.navigate(key);
		LOGGER.debug("Page URL={}", url);
	}

	@Given("I loaded Spectrum Page: {string}")
	public void Load_Spectrum_Page(String key) throws Throwable {
		String url = selenium.navigate(key);
		selenium.waitForAngular();
		LOGGER.debug("Page URL={}", url);
	}
	
	@Then("I Should See Page Title: {string}")
	public void I_Should_See_Page_Title(String expected) throws Throwable {
		String actual = selenium.getPageTitle();
		LOGGER.debug("Page Title={}", actual);
		Assertions.assertThat(actual).isEqualTo(expected);
	}
	
//	@Then("I click on Internet Tab")
//	public void internetTabClick() {
//		specHome.internetTabClick();
//	}
	
	@Then("I click on offer tab")
	public void offerTab() {
		specHome.offerTabClick();
	}
	
}
