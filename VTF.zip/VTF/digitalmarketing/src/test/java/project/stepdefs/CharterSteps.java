package project.stepdefs;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import cucumber.api.java.en.Then;
import project.domain.page.SpectrumHomePage;
import com.charter.web.Selenium;

/**
 * Define reusable steps for any application.
 */
public class CharterSteps {

	private static final Logger LOGGER = LoggerFactory.getLogger(CharterSteps.class);
	private Selenium selenium = null;
	private SpectrumHomePage spec =null;

	public CharterSteps(ContextSteps contextSteps) {
		selenium = contextSteps.getSelenium();
		spec = new SpectrumHomePage(selenium);
		
	}
	
	@Then("I Should See Page Title")
	public void I_Should_See_Page_Title() throws Throwable {
		String actual = selenium.getPageTitle();
		LOGGER.debug("Page Title={}", actual);
		spec = new SpectrumHomePage(selenium);
		spec.businessLinkClick();
		System.out.print("Page Title={}----------    "+actual);
	}

}
