//<!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd" >
package project.api;

import java.util.List;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import cucumber.api.java.en.When;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

import project.api.SpectrumAPIBuilder;
import project.domain.page.SpectrumHomePage;
import com.charter.api.APIManager;
import com.charter.utils.ConfigUtil;
import com.charter.utils.ExcelXSSFUtility;
import com.charter.web.Selenium;


public class SpectrumAPITests {
	
	@When("Run Iterator method for key {string}")
	public void iteratorMethod(String key) {
		//ConfigUtil.CONFIG_ENV = "production";
		
		System.out.println("Key: " + key);
		System.out.println("Val: " + ConfigUtil.CONFIG_GET_STRING(key));
		
		String excelKey = ConfigUtil.CONFIG_GET_STRING(key);
		List<String> values = ExcelXSSFUtility.valuesFor(excelKey);
		
		List<String> channelValues = ExcelXSSFUtility.valuesFor("channel");
		
        
		System.out.println("S: "+channelValues.size());
		for(int i = 0; i < values.size(); i++) {
			for(int j = 0; j < channelValues.size(); j++) {
				iteratableMethod(values.get(i), channelValues.get(j));
			}
		}
		
	}
	
	@Test(description = "Iteratable Method")
	public void iteratableMethod(String value, String channel) {
		System.out.println("Excel: " + value + ", " + channel);
		SpectrumAPIBuilder.specAuthRequest();
		//ResponseBody response = SpectrumAPIBuilder.specProductCatalogRequest(value, channel);
		
	}
	
	Response activeResponse;
	
	String authCode           = "";
	String access_token       = "";
	String id_token           = "";
	String refresh_token      = "";
	String mbo_access_token   = "";
	String akana_access_token = "";
	
	@Then("Verify that I have recieved the {string}")
	public void assertAuthCodePresent(String key) {
		APIManager.verifyHasKey(activeResponse, key);
	}
	
	@Then("Verify that Server responded OK")
	public void assertResponseOK() {
		APIManager.verifyResponseOK(activeResponse);
	}
	
	@Then("Verify that response has key {string} with value {string}")
	public void assertKeyHasValue(String key, String value) {
		APIManager.keyHasValue(activeResponse, key, value);
	}
	@Then("Verify that response has key {string} with value {int}")
	public void assertKeyHasValue(String key, int value) {
		APIManager.keyHasValue(activeResponse, key, value);
	}
	@Then("Verify that response has key {string} with boolean value {string}")
	public void assertKeyHasBooleanValue(String key, String value) {
		APIManager.keyHasValue(activeResponse, key, value.equals("true") );
	}
	
	
	@Given("I Request autherization code from Spectrum Server")
	@Test
	public void specAuthTest() {
		activeResponse = SpectrumAPIBuilder.specAuthRequest();
		ResponseBody response = activeResponse.getBody();
		
		authCode = response.jsonPath().getString("authCode");
		
	}
	
	
	@Given("I Request session tokens from Spectrum Server")
	@Test(description = "Test Token based on authCode", dependsOnMethods = "specAuthTest")
	public void specTokenTest() {
		
		System.out.println("AUTH CODE: " + authCode + "\n");
		activeResponse = null;
		activeResponse = SpectrumAPIBuilder.specTokenRequest(authCode);
		ResponseBody response = activeResponse.getBody();
		
		access_token       = response.jsonPath().getString("access_token");
		id_token           = response.jsonPath().getString("id_token");
		refresh_token      = response.jsonPath().getString("refresh_token");
		mbo_access_token   = response.jsonPath().getString("mbo_access_token");
		akana_access_token = response.jsonPath().getString("akana_access_token");
		
		System.out.println("MBO: " + response.asString());
		System.out.println("MBO: " + mbo_access_token);
	}
	
	@When("I Login to the spectrum mobile api")
	@Test(description = "Test Login based on tokens recieved from the token api", dependsOnMethods = "specTokenTest")
	public void specLoginTest() {
		activeResponse = SpectrumAPIBuilder.specLoginRequest(akana_access_token, mbo_access_token);
		ResponseBody response = activeResponse.getBody();
	}
	
	@When("I Check users elegibility")
	@Test(description = "Test user elegibility", dependsOnMethods = "specTokenTest")
	public void specBuyInfoEligibilityTest() {
		activeResponse = SpectrumAPIBuilder.specBuyInfoEligibilityRequest(akana_access_token, mbo_access_token);
		ResponseBody response = activeResponse.getBody();
	}
	
	@When("I Request public key")
	@Test(description = "Test Fetch public key", dependsOnMethods = "specTokenTest")
	public void specPublicKeyTest() {
		activeResponse = SpectrumAPIBuilder.specPublicKeyRequest(akana_access_token);
		ResponseBody response = activeResponse.getBody();
	}
}
