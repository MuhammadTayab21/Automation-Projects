package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginDemoSteps {

//	WebDriver driver = null;
//	
//	@Given("Browser is open")
//	public void browser_is_open() {
//	    System.out.println("inside steps - Browser is open");
//	    String projectpath=System.getProperty("user.dir");
//		   System.out.println("Project path is: "+projectpath);
//		   System.setProperty("WebDriver.chrome.driver",projectpath+"/src/test/resources/Driver/chromedriver.exe");
//		   driver = new ChromeDriver();
//		   driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page1")
//	public void user_is_on_login_page1() {
//	    System.out.println("inside steps - user is on login page1");
//	    driver.navigate().to("https://example.testproject.io/web/");
//	}
//
//	@When("^user enters (.*) and (.*) in fields$")
//	public void user_enters_username_and_password_in_fields(String username,String password) throws InterruptedException {
//	    System.out.println("inside steps - user enters username and password in fields");
//	    driver.findElement(By.id("name")).sendKeys(username);
//	    driver.findElement(By.id("password")).sendKeys(password);
//	    Thread.sleep(2000);
//	}
//	
//	@And("user click on login button")
//	public void user_click_on_login_button() throws InterruptedException {
//	    System.out.println("inside steps - user click on login button");
//	    driver.findElement(By.id("login")).click();
//	    Thread.sleep(2000);
//	}
//	
//	@Then("user is navigated to the new page")
//	public void user_is_navigated_to_the_new_page() {
//		System.out.println("inside steps - user is navigated to the new page");
//		driver.findElement(By.id("logout")).isDisplayed();
//		driver.close();
//		driver.quit();
//	}
}
