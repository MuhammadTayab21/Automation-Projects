package Specturm_Definition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Spect_Definition {
	static WebDriver driver = new FirefoxDriver();
	Spect_Functions common_method = new Spect_Functions(driver);
	
	@BeforeAll
	public static void beforeall() {
		System.setProperty("webdriver.geckodriver.driver","src\\test\\resources\\Driver\\geckodriver.exe");
		driver.get("https://www.spectrum.com/");
	}
	
	@When("enter URL in address bar and website open")
	public void enter_url_in_address_bar_and_website_open() throws InterruptedException {
		common_method.mobile_tab_hover();
	}
	
	@Then("click on Mobile link")
	public void click_on_Mobile_link() {
		
	}
	
	@When("Click on Apple category and select pro max")
	public void click_on_apple_category_and_select_pro_max() throws InterruptedException {
	   common_method.select_mobile_category();
	}

	@Then("complete order process")
	public void complete_order_process() {
	    
	}
}
