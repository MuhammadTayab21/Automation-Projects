package Specturm_Definition;

import org.openqa.selenium.By;
import java.time.Duration;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Spect_Functions {
	WebDriver driver;
	
	
	@FindBy(xpath="(//a[@class='cmp-navigation__item-link' and @title='Mobile' ])[1]")
	WebElement Mobile_tab;
	
	@FindBy(xpath="(//a[@class='cmp-navigation__item-link' and @title='Spectrum Mobile'])[1]")
	WebElement spectrum_mobile;
	
	@FindBy(id="collapsible-nav-dropdown-0")
	WebElement plans;
	
	@FindBy(xpath="(//a[@class='dropdown-item' and @data-linkname='Mobile Data Plans'])[1]")
	WebElement mobiledata_plans;

	@FindBy(xpath="//*[text()[contains(.,'SHOP NOW')]]")
	WebElement shopnow;
	
	@FindBy(xpath="//a[text()[contains(.,'Apple')]]")
	WebElement apple;
	

	@FindBy(xpath="//img[@class='product-image img-responsive img-fluid' and @alt='Apple iPhone 14 Pro Max Deep Purple']")
	WebElement iphone14promax;
	
	@FindBy(xpath="//button[@class='variant-circle gold false' and @aria-label='Gold']")
	WebElement mobilecolor;
	
	@FindBy(xpath="//span[text()[contains(.,'256 GB')]]")
	WebElement capacity;
	
	@FindBy(xpath="//span[text()[contains(.,'$1199.99')]]")
	WebElement paymentinfo;
	
	@FindBy(xpath="//span[text()[contains(.,'Add Protection Plan')]]")
	WebElement applecareservices;
	
	@FindBy(xpath="//button[text()[contains(.,'Decline Trade-In')]]")
	WebElement tradein;
	
	@FindBy(xpath="//button[text()[contains(.,'CONTINUE')]]")
	WebElement continuebutton;
	
	@FindBy(xpath="(//button[@class='cmp-button'])[1]")
	WebElement signin;
	
	@FindBy(id="cc-username")
	WebElement username;
	
	@FindBy(id="cc-user-password")
	WebElement password;
	
	@FindBy(xpath="//span[@class='kite-custom-control-indicator']")
	WebElement rememberusername;
	
	@FindBy(xpath="//button[@class='dialog_button kite-btn ngk-button kite-typography kite-btn-primary kite-btn-lg kite-theme-primary']")
	WebElement submit;
	
	public Spect_Functions(WebDriver d) {
		driver=d;
		PageFactory.initElements(d, this);
	}
	
	public void mobile_tab_hover() throws InterruptedException {
		Actions action = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		action.moveToElement(Mobile_tab).build().perform();
		spectrum_mobile.click();
		action.moveToElement(plans).build().perform();
	    mobiledata_plans.click();
	    shopnow.click();
	    action.sendKeys(Keys.PAGE_DOWN).build().perform();
	    //Thread.sleep(3000);
	    wait.until(ExpectedConditions.visibilityOf(apple));
	    apple.click();
	}
	
	public void select_mobile_category() throws InterruptedException {
		Actions action = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		Thread.sleep(3000);
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		wait.until(ExpectedConditions.visibilityOf(iphone14promax));
		iphone14promax.click();
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		wait.until(ExpectedConditions.visibilityOf(mobilecolor));
		//Thread.sleep(3000);
		mobilecolor.click();
		capacity.click();
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		paymentinfo.click();
		applecareservices.click();
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		tradein.click();
		continuebutton.click();
		Thread.sleep(3000);
		signin.click();
		Thread.sleep(7000);
		username.sendKeys("sample@gmail.com");
		password.sendKeys("jangoStyle221");
		Thread.sleep(5000);
		rememberusername.click();
		Thread.sleep(3000);
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		submit.click();
	    
	}
}
	
